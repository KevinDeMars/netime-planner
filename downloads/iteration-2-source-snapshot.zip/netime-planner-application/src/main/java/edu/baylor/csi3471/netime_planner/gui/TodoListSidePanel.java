package edu.baylor.csi3471.netime_planner.gui;

import javax.swing.*;

public class TodoListSidePanel extends JPanel {
    public TodoListSidePanel() {
        add(new JLabel("Todo List"));
    }
}
