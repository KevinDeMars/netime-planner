package edu.baylor.csi3471.netime_planner.models;

public enum GroupPermission {
}
